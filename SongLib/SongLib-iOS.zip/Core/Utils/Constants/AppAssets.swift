//
//  AppAssets.swift
//  SongLib
//
//  Created by Siro Daves on 30/04/2025.
//

struct AppAssets {
    static let mainIcon = "MainIcon"
    static let emptyIcon = "EmptyIcon"
}
